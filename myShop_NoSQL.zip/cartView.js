// express 모듈을 가져와서 라우터를 생성합니다.
const express = require('express');
const router = express.Router(); // 새로운 라우터 객체 생성
const { ObjectId } = require('mongodb'); // MongoDB의 ObjectId 가져오기
const db = require('./db'); // 데이터베이스 연결 모듈
const cors = require('cors'); // CORS 미들웨어
var authCheck = require('./authCheck.js'); // 인증 관련 기능을 위한 모듈

const app = express(); // Express 애플리케이션 생성
app.use(cors()); // CORS를 사용하여 모든 출처에 대해 허용

// 장바구니 페이지 요청 처리
router.get('/', async (req, res) => {
    try {
        const statusUI = await authCheck.statusUI(req, res); // 로그인 상태 UI 가져오기
        const username = statusUI.split(' ')[0]; // 사용자 이름 추출
  
        // 사용자와 장바구니 정보 조회
        const user = await db.users.findOne(
            { username: username }, // 사용자 이름으로 검색
            { projection: { cart: 1 } }  // cart 필드만 가져오기
        );

        // 사용자가 존재하지 않는 경우
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // 장바구니가 비어있는 경우 처리
        if (!user.cart || user.cart.length === 0) {
            return res.json([]); // 빈 배열 반환
        }

        // 장바구니 아이템 포맷팅
        const cartItems = user.cart.map((item, index) => ({
            cid: index,  // 고유 식별자로 인덱스 사용
            pname: item.product_name, // 상품 이름
            price: item.price, // 가격
            size: item.size, // 사이즈
            qty: item.quantity, // 수량
            type: item.type, // 상품 종류
            material: item.material // 소재
        }));
        
        // HTML 템플릿 생성
        var html = `
          <html lang="ko">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>장바구니</title>
              <style>
                  body { font-family: Arial, sans-serif; }
                  .cart-item { border: 1px solid #ddd; margin: 10px; padding: 10px; }
                  #cartTotal { font-weight: bold; margin-top: 20px; }
              </style>
          </head>
          <body>
              <h1>장바구니</h1>
              <h2>회원 ID : ${username}</h2>
              <div id="cartItems">
                  ${cartItems.map(item => `
                      <div class="cart-item">
                          <h3>${item.pname}</h3>
                          <p>가격: ${item.price}원</p>
                          <p>사이즈: 
                              <select class="size-select" data-id="${item.cid}">
                                  <option value="small" ${item.size === 'small' ? 'selected' : ''}>소</option>
                                  <option value="medium" ${item.size === 'medium' ? 'selected' : ''}>중</option>
                                  <option value="large" ${item.size === 'large' ? 'selected' : ''}>대</option>
                              </select>
                          </p>
                          <p>수량: 
                              <input type="number" class="quantity-input" data-id="${item.cid}" value="${item.qty}" min="1" max="10">
                          </p>
                          <button class="remove-item" data-id="${item.cid}">삭제</button>
                      </div>
                  `).join('')}
              </div>
              <div id="cartTotal">총 금액: <span id="totalAmount">0</span>원</div>
              <button id="paymentButton">결제하기</button>
        
              <script>
                 // 장바구니 아이템 가져오기
                async function fetchCartItems() {
                    try {
                        const response = await fetch('/cart/cart_view'); // 장바구니 조회 API 호출
                        if (!response.ok) {
                            throw new Error("HTTP error! status:" + response.status); // 오류 발생 시 예외 처리
                        }
                        const cartItems = await response.json(); // JSON 형식으로 응답 받기
                        displayCartItems(cartItems); // 장바구니 아이템 표시 함수 호출
                        console.error('장바구니 아이템을 가져옴');
                    } catch (error) {
                        console.error('장바구니 아이템을 가져오는 중 오류 발생:', error);
                        document.getElementById('cartItems').innerHTML = '장바구니를 불러오는 중 오류가 발생했습니다.'; // 오류 메시지 표시
                    }
                }        
        
              // 장바구니 아이템 표시
              function displayCartItems(items) {
                  const cartItemsContainer = document.getElementById('cartItems');
                  cartItemsContainer.innerHTML = ''; // 기존 아이템 초기화
                  let total = 0; // 총 금액 초기화
        
                  items.forEach(item => {
                      const itemElement = document.createElement('div'); // 새로운 div 요소 생성
                      itemElement.className = 'cart-item'; // 클래스 지정
                      itemElement.innerHTML = '<h3>' + item.pname + '</h3>' +
                          '<p> 장바구니번호: ' + item.cid + '</p>' +
                          '<p>가격: ' + item.price + '원</p>' +
                          '<p>사이즈: ' +
                              '<select class="size-select" data-id="' + item.cid + '">' +
                                  '<option value="small"' + (item.size === 'small' ? ' selected' : '') + '>소</option>' +
                                  '<option value="medium"' + (item.size === 'medium' ? ' selected' : '') + '>중</option>' +
                                  '<option value="large"' + (item.size === 'large' ? ' selected' : '') + '>대</option>' +
                              '</select>' +
                          '</p>' +
                          '<p>수량: ' +
                              '<input type="number" class="quantity-input" data-id="' + item.cid + '" value="' + item.qty + '" min="1" max="10">' +
                          '</p>' +
                          '<button class="remove-item" data-id="' + item.cid + '">삭제</button>';
                      cartItemsContainer.appendChild(itemElement); // 요소를 컨테이너에 추가
                      total += item.price * item.qty; // 총 금액 계산
                  });
        
                  document.getElementById('totalAmount').textContent = total.toLocaleString(); // 총 금액 표시
        
                  // 이벤트 리스너 추가
                  addEventListeners();
              }
        
              // 이벤트 리스너 추가 함수
              function addEventListeners() {
                  // 수량 변경 이벤트
                  document.querySelectorAll('.quantity-input').forEach(input => {
                      input.addEventListener('change', handleQuantityChange); // 수량 변경 시 핸들러 호출
                  });
              
                  // 사이즈 변경 이벤트
                  document.querySelectorAll('.size-select').forEach(select => {
                      select.addEventListener('change', handleSizeChange); // 사이즈 변경 시 핸들러 호출
                  });
              
                  // 삭제 버튼 이벤트
                  document.querySelectorAll('.remove-item').forEach(button => {
                      button.addEventListener('click', handleRemoveItem); // 삭제 버튼 클릭 시 핸들러 호출
                  });
              
                  // 결제 버튼 이벤트
                  const paymentButton = document.getElementById('paymentButton');
                  paymentButton.removeEventListener('click', handlePayment); // 기존 이벤트 제거
                  paymentButton.addEventListener('click', handlePayment); // 결제 버튼 클릭 시 핸들러 호출
              }
              
              // 수량 변경 핸들러
              async function handleQuantityChange() {
                  const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
                  const newQuantity = this.value; // 새로운 수량 값
                  await updateCartItem(id, { quantity: newQuantity }); // 장바구니 아이템 업데이트
              }
              
              // 사이즈 변경 핸들러
              async function handleSizeChange() {
                  const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
                  const newSize = this.value; // 새로운 사이즈 값
                  await updateCartItem(id, { size: newSize }); // 장바구니 아이템 업데이트
              }
              
              // 삭제 핸들러
              async function handleRemoveItem() {
                  const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
                  await removeCartItem(id); // 장바구니 아이템 삭제
              }
              
              // 결제 핸들러
              async function handlePayment() {
                  await processPayment(); // 결제 처리
              }

              async function updateCartItem(id, updates) {
                  try {
                      const response = await fetch('/cart/' + id, {
                          method: 'PUT',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify(updates)
                      });
                      if (!response.ok) throw new Error('Failed to update cart item');
                      console.log('장바구니가 업데이트되었습니다. id : ', id);
                      await fetchCartItems(); // 장바구니 새로고침
                  } catch (error) {
                      console.error('Cart update error:', error);
                      alert('장바구니 업데이트에 실패했습니다.');
                  }
              }
            
              async function removeCartItem(id) {
                  try {
                      const response = await fetch('/cart/' + id, { method: 'DELETE' });
                      if (!response.ok) throw new Error('Failed to remove cart item');
                      console.log('장바구니가 품목이 삭제되었습니다. id : ', id);
                      await fetchCartItems(); // 장바구니 새로고침
                  } catch (error) {
                      console.error('Cart removal error:', error);
                      alert('상품 삭제에 실패했습니다.');
                  }
              }
              
              async function processPayment() {
                  try {
                    const response = await fetch('/cart/pay', { 
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json'
                      }
                    });
                    if (!response.ok) throw new Error('Failed to process payment');
                    const result = await response.json();
                    alert(result.message);
                    await fetchCartItems(); // 장바구니 새로고침
                  } catch (error) {
                    console.error('Payment error:', error);
                    alert('결제 처리에 실패했습니다.');
                  }
              }   
            
              // 페이지 로드 시 장바구니 아이템 가져오기
              fetchCartItems();
            </script>
          </body>
          </html>`;
        
        res.send(html);
    } catch (error) {
        console.error('장바구니 페이지 로드 오류:', error);
        res.status(500).send('서버 오류가 발생했습니다.');
    }
});

// 장바구니 조회
router.get('/cart_view', async (req, res) => {
    try {
        const statusUI = await authCheck.statusUI(req, res);
        const username = statusUI.split(' ')[0];

        // 사용자와 장바구니 정보 조회
        const user = await db.users.findOne(
            { username: username },
            { projection: { cart: 1 } }  // cart 필드만 가져오기
        );

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // 장바구니가 비어있는 경우 처리
        if (!user.cart || user.cart.length === 0) {
            return res.json([]);
        }

        // 장바구니 아이템 포맷팅
        const formattedCartItems = user.cart.map((item, index) => ({
            cid: index,  // 고유 식별자로 인덱스 사용
            pname: item.product_name,
            price: item.price,
            size: item.size,
            qty: item.quantity,
            type: item.type,
            material: item.material
        }));

        res.json(formattedCartItems);
    } catch (error) {
        console.error('장바구니 조회 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

// 장바구니 아이템 업데이트
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { size, quantity } = req.body;
        const index = parseInt(id);

        // 유효성 검사
        if (isNaN(index)) {
            return res.status(400).json({ 
                message: '유효하지 않은 장바구니 아이템 인덱스입니다.' 
            });
        }

        // 현재 사용자 확인
        const statusUI = await authCheck.statusUI(req, res);
        const username = statusUI.split(' ')[0];

        // 업데이트할 필드 설정
        const update = {};
        if (size) update[`cart.${index}.size`] = size;
        if (quantity) update[`cart.${index}.quantity`] = parseInt(quantity);

        // 해당 인덱스의 아이템이 존재하는지 먼저 확인
        const user = await db.users.findOne(
            { username: username },
            { projection: { [`cart.${index}`]: 1 } }
        );

        if (!user || !user.cart || !user.cart[index]) {
            return res.status(404).json({ 
                message: '업데이트할 장바구니 아이템을 찾을 수 없습니다.' 
            });
        }

        // 장바구니 아이템 업데이트
        const result = await db.users.updateOne(
            { username: username },
            { $set: update }
        );

        if (result.modifiedCount === 0) {
            return res.status(404).json({ 
                message: '장바구니 업데이트에 실패했습니다.' 
            });
        }

        // 업데이트된 장바구니 아이템 조회
        const updatedUser = await db.users.findOne(
            { username: username },
            { projection: { [`cart.${index}`]: 1 } }
        );

        res.json({ 
            message: '장바구니가 업데이트되었습니다.',
            updatedItem: updatedUser.cart[index]
        });

    } catch (error) {
        console.error('장바구니 업데이트 오류:', error, error.stack);
        res.status(500).json({ 
            error: '서버 오류가 발생했습니다.',
            details: error.message 
        });
    }
});

// 장바구니 아이템 삭제
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const index = parseInt(id);  // 클라이언트에서 받은 인덱스
        
        // 현재 로그인한 사용자 확인
        const statusUI = await authCheck.statusUI(req, res);
        const username = statusUI.split(' ')[0];
        
        // 인덱스 유효성 검사
        if (isNaN(index)) {
            return res.status(400).json({ 
                message: '유효하지 않은 장바구니 아이템 인덱스입니다.' 
            });
        }

        // 사용자의 장바구니에서 해당 인덱스의 아이템 삭제
        const result = await db.users.updateOne(
            { username: username },
            { 
                $unset: { [`cart.${index}`]: 1 }  // 해당 인덱스의 아이템을 null로 설정
            }
        );

        // null이 된 요소들을 제거
        await db.users.updateOne(
            { username: username },
            { 
                $pull: { cart: null }  // null인 요소들을 제거
            }
        );

        if (result.modifiedCount === 0) {
            return res.status(404).json({ 
                message: '삭제할 장바구니 아이템을 찾을 수 없습니다.' 
            });
        }

        res.json({ 
            message: '상품이 장바구니에서 삭제되었습니다.',
            index: index
        });

    } catch (error) {
        console.error('장바구니 삭제 오류:', error);
        res.status(500).json({ 
            error: '서버 오류가 발생했습니다.',
            details: error.message 
        });
    }
});

// 결제 처리
router.post('/pay', async (req, res) => {
    const session = db.client.startSession();
    try {
        const statusUI = await authCheck.statusUI(req, res);
        const username = statusUI.split(' ')[0];
        
        await session.withTransaction(async () => {
            // 사용자 정보와 장바구니 조회
            const user = await db.users.findOne({ username: username });
            if (!user) {
                throw new Error('User not found');
            }

            // 장바구니가 비어있는지 확인
            if (!user.cart || user.cart.length === 0) {
                throw new Error('Cart is empty');
            }

            // 새로운 주문 생성
            const newOrder = {
                order_id: Date.now(), // 고유한 주문 ID 생성
                order_date: new Date().toISOString().split('T')[0], // YYYY-MM-DD 형식
                items: user.cart.map(item => ({
                    product_id: item.product_id,
                    product_name: item.product_name,
                    price: item.price,
                    type: item.type,
                    material: item.material,
                    size: item.size,
                    quantity: item.quantity
                }))
            };

            // orders 배열에 새 주문 추가하고 장바구니 비우기
            const result = await db.users.updateOne(
                { username: username },
                {
                    $push: { orders: newOrder },  // 새 주문 추가
                    $set: { cart: [] }            // 장바구니 비우기
                }
            );

            if (result.modifiedCount === 0) {
                throw new Error('Order update failed');
            }

            console.log('주문 처리 완료:', {
                username,
                orderId: newOrder.order_id,
                itemCount: newOrder.items.length
            });
        });

        res.json({ 
            message: `${username} paid successfully!`,
            status: 'success'
        });

    } catch (error) {
        console.error('결제 처리 오류:', error);
        res.status(500).json({ 
            error: '서버 오류가 발생했습니다.',
            message: error.message 
        });
    } finally {
        await session.endSession();
    }
});

module.exports = router;