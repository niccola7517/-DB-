// authCheck.js
// db 모듈을 가져옵니다. 데이터베이스와의 상호작용을 위한 객체입니다.
const db = require('./db');

// AuthCheck 클래스를 정의합니다. 이 클래스는 인증 관련 기능을 제공합니다.
class AuthCheck {
    // 로그인 상태 확인 메서드
    static async isOwner(request, response) {
        // 세션에 로그인 상태가 있는지 확인
        if (request.session.is_logined) {
            try {
                // 세션의 사용자가 실제로 DB에 존재하는지 확인 (선택적)
                const user = await db.users.findOne({ username: request.session.nickname });
                return !!user; // user가 존재하면 true, 없으면 false 반환
            } catch (error) {
                console.error('사용자 확인 중 오류 발생:', error); // 오류 로깅
                return false; // 오류 발생 시 false 반환
            }
        }
        return false; // 로그인 상태가 아니면 false 반환
    }

    // 로그인 상태에 따라 UI 텍스트 생성
    static async statusUI(request, response) {
        try {
            // 로그인된 사용자인지 확인
            if (await this.isOwner(request, response)) {
                // 로그인된 사용자의 정보를 DB에서 가져옴 (선택적)
                const user = await db.users.findOne({ username: request.session.nickname });
                if (user) {
                    // 사용자 이름과 로그아웃 링크를 포함한 환영 메시지 반환
                    return `${user.username} 님 환영합니다 | <a href="/auth/logout">로그아웃</a>`;
                }
            }
        } catch (error) {
            console.error('상태 UI 생성 중 오류 발생:', error); // 오류 로깅
        }
        
        // 로그인되지 않은 사용자에 대한 기본 메시지 반환
        return '로그인후 사용 가능합니다';
    }

    // 인증 미들웨어 메서드
    static async requireAuth(request, response, next) {
        try {
            // 사용자가 로그인된 상태인지 확인
            if (await AuthCheck.isOwner(request, response)) {
                next(); // 인증된 사용자는 다음 미들웨어로 진행
            } else {
                // 인증되지 않은 사용자는 로그인 페이지로 리디렉션
                response.redirect('/auth/login'); // 로그인 페이지로 리디렉션
            }
        } catch (error) {
            console.error('인증 확인 중 오류 발생:', error); // 오류 로깅
            response.status(500).send('서버 오류가 발생했습니다.'); // 서버 오류 응답
        }
    }
}

// AuthCheck 클래스를 외부에서 사용할 수 있도록 모듈 내보내기
module.exports = AuthCheck;