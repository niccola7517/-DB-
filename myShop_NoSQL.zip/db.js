// db.js
// MongoDB 드라이버에서 MongoClient 클래스 가져오기
const { MongoClient } = require('mongodb');
// 파일 경로 처리를 위한 Node.js 내장 모듈
const path = require('path');

// DocumentDB 연결 문자열 구성
// - docdbdb000:docdb1234 : 사용자 이름과 비밀번호
// - docdb-2024-11-11-06-02-35.cluster-cdsomq8mgfd0.ap-south-1.docdb.amazonaws.com : DocumentDB 엔드포인트
// - shopping_db : 데이터베이스 이름
// - tls=true : SSL/TLS 보안 연결 사용
// - replicaSet=rs0 : DocumentDB 복제본 세트 이름
// - readPreference=secondaryPreferred : 읽기 작업을 보조 노드에서 우선 실행
// - retryWrites=false : 쓰기 작업 재시도 비활성화 (DocumentDB 제약사항)
const uri = 'mongodb://docdbdb000:docdb1234@docdb-2024-11-11-06-02-35.cluster-cdsomq8mgfd0.ap-south-1.docdb.amazonaws.com:27017/shopping_db?tls=true&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false';

// MongoDB 클라이언트 객체 생성
const client = new MongoClient(uri, {
    tls: true,  // TLS/SSL 보안 연결 활성화
    tlsCAFile: '/home/ec2-user/docDB/global-bundle.pem',  // AWS 제공 인증서 파일 경로
    authMechanism: 'SCRAM-SHA-1',  // DocumentDB 인증 메커니즘 지정
    directConnection: true  // 단일 서버에 직접 연결 (로드 밸런싱 무시)
});

// 데이터베이스 인스턴스를 저장할 변수 (모듈 내부에서 공유)
let dbInstance = null;

// 데이터베이스 작업을 위한 메인 객체
const db = {
    // 데이터베이스 연결 초기화 함수
    connect: async function() {
        try {
            // DocumentDB에 연결
            await client.connect();
            console.log('데이터베이스에 성공적으로 연결되었습니다.');
            
            // 데이터베이스 인스턴스 가져오기
            dbInstance = client.db('shopping_db');
            
            // 컬렉션 참조 설정
            // 이를 통해 db.users.findOne() 같은 방식으로 직접 접근 가능
            this.users = dbInstance.collection('users');      // 사용자 정보 컬렉션
            this.products = dbInstance.collection('products'); // 상품 정보 컬렉션
        } catch (err) {
            console.error('데이터베이스 연결 오류:', err);
            throw err;  // 상위 호출자에게 에러 전파
        }
    },

    // 컬렉션 참조를 저장할 속성들
    // connect() 호출 전까지는 null 상태 유지
    users: null,    // 사용자 컬렉션 참조
    products: null, // 상품 컬렉션 참조
    
    // 중첩 문서로 처리되는 컬렉션들 (별도 참조 불필요)
    // cart: null,     // 장바구니 컬렉션 참조
    // orders: null,   // 주문 컬렉션 참조
    // orderItems: null, // 주문 상세 컬렉션 참조

    // 외부에서 MongoDB 클라이언트 객체 접근용 (트랜잭션 등에 사용)
    client: client,

    // 데이터베이스 연결 종료 함수
    close: async function() {
        if (client) {
            await client.close();        // 연결 종료
            dbInstance = null;           // 인스턴스 참조 제거
            console.log('데이터베이스 연결이 종료되었습니다.');
        }
    }
};

// 모듈 로드 시 자동으로 데이터베이스 연결 시도
// 실패 시 에러 로깅만 하고 프로세스는 계속 실행
db.connect().catch(console.error);

// 데이터베이스 객체 외부 노출
module.exports = db;