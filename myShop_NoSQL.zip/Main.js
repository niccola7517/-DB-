// Main.js
// 필요한 모듈 임포트
const express = require('express');                    // Express 웹 프레임워크
const session = require('express-session');            // 세션 관리 미들웨어
const bodyParser = require('body-parser');             // 요청 본문 파싱 미들웨어
const FileStore = require('session-file-store')(session); // 세션을 파일로 저장하는 모듈
const cors = require('cors');                          // CORS 지원 미들웨어
const path = require('path');                          // 파일 경로 처리 모듈
const { ObjectId } = require('mongodb');               // MongoDB ObjectId 변환용
const fs = require('fs');                              // 파일 시스템 접근 모듈

// 사용자 정의 모듈 임포트
var authRouter = require('./auth');           // 인증 관련 라우터
var authCheck = require('./authCheck.js');    // 인증 상태 확인 모듈
var template = require('./template.js');      // HTML 템플릿 모듈
var db = require('./db.js');                 // 데이터베이스 연결 모듈
var cartRouter = require('./cartView.js');    // 장바구니 관련 라우터

// 세션 파일 저장을 위한 디렉토리 설정
const sessionsDir = 'sessions';
if (!fs.existsSync(sessionsDir)) {
    fs.mkdirSync(sessionsDir);     // sessions 디렉토리가 없으면 생성
}

// Express 앱 초기화
const app = express();
const port = 3000;

// 미들웨어 설정
app.use(cors());                    // CORS 활성화
app.use(express.json());           // JSON 요청 본문 파싱
app.use(bodyParser.urlencoded({ extended: true }));  // URL-encoded 요청 파싱

// 세션 미들웨어 설정
app.use(session({
    secret: '~~~',                // 세션 데이터 암호화 키
    resave: false,                // 세션 데이터가 변경되지 않아도 다시 저장하지 않음
    saveUninitialized: true,      // 초기화되지 않은 세션도 저장
    store: new FileStore({        // 세션 저장소 설정
        path: sessionsDir,        // 세션 파일 저장 경로
        logFn: function(){},      // 로그 비활성화
        retries: 0,               // 재시도 횟수
        ttl: 24 * 60 * 60        // 세션 유효기간 (24시간)
    }),
}));

// 장바구니 관련 라우트
app.use('/cart', cartRouter);

// 메인 라우트 - 홈페이지 접속 처리
app.get('/', async (req, res) => {
    try {
        // 로그인 상태 확인
        if (!await authCheck.isOwner(req, res)) {
            res.redirect('/auth/login');  // 비로그인 시 로그인 페이지로 리다이렉트
            return;
        }
        res.redirect('/main');        // 로그인 상태면 메인 페이지로 리다이렉트
    } catch (error) {
        console.error('Authentication error:', error);
        res.redirect('/auth/login');
    }
});

// 인증 라우터
app.use('/auth', authRouter);

// 메인 페이지
app.get('/main', async (req, res) => {
    try {
        if (!await authCheck.isOwner(req, res)) {
            res.redirect('/auth/login');
            return;
        }

        const usermenu = await authCheck.statusUI(req, res);
        const username = usermenu.split(' ')[0];

        var html = `
          <html lang="ko">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>의류 쇼핑몰</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    background-color: #f0f0f0;
                }
                h1 {
                    text-align: center;
                    color: #333;
                }
                .product-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                    gap: 20px;
                    padding: 20px;
                }
                .product-card {
                    background-color: white;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    overflow: hidden;
                    transition: transform 0.3s ease;
                }
                .product-card:hover {
                    transform: translateY(-5px);
                }
                .product-image {
                    width: 100%;
                    height: 200px;
                    object-fit: cover;
                }
                .product-info {
                    padding: 15px;
                }
                .product-name {
                    font-size: 18px;
                    font-weight: bold;
                    margin: 0 0 10px 0;
                }
                .product-details {
                    font-size: 14px;
                    color: #666;
                    margin: 5px 0;
                }
                .product-price {
                    font-size: 16px;
                    font-weight: bold;
                    color: #e44d26;
                    margin: 10px 0 0 0;
                }
                button {
                    display: block;
                    width: 100%;
                    padding: 10px;
                    background-color: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 16px;
                    margin-top: 10px;
                }
                button:hover {
                    background-color: #45a049;
                }
            </style>
          </head>
          <body>
            <h1>의류 쇼핑몰 상품 목록</h1>
            <h2>회원 ID : ${usermenu}</h2>
            <a href="/cart" id="cartLink">장바구니 보기</a>
            <div id="productGrid" class="product-grid">
                <!-- 상품 카드가 여기에 동적으로 추가됩니다 -->
            </div>
            <script>
              // 서버에서 상품 데이터 가져오기
              async function fetchProducts() {
                  try {
                      const response = await fetch('/api/products');
                      if (!response.ok) {
                          throw new Error("HTTP error! status:" + response.status);
                      }
                      const products = await response.json();
                      console.log(products)
                      displayProducts(products);
                  } catch (error) {
                      console.error('상품을 가져오는 중 오류 발생:', error);
                      document.getElementById('productGrid').innerHTML = '상품을 불러오는 중 오류가 발생했습니다.';
                  }
              }
              
                // 상품 목록 표시
                function displayProducts(products) {
                    const productGrid = document.getElementById('productGrid');
                    console.log('Received products:', products); // 디버깅용
                    productGrid.innerHTML = '';
                    products.forEach(product => {
                        const productCard = document.createElement('div');
                        productCard.className = 'product-card';
                        productCard.innerHTML = 
                            '<div class="product-info">' +
                            '<h2 class="product-name">' + product.pname + '</h2>' +
                            '<p class="product-details">종류: ' + product.ptype + '</p>' +
                            '<p class="product-details">소재: ' + product.material + '</p>' +
                            '<p class="product-price">' + product.price.toLocaleString() + '원</p>' +
                            '<div class="product-options">' +
                                '<label for="size-' + product._id + '">사이즈: </label>' +
                                '<select id="size-' + product._id + '" class="size-select">' +
                                    '<option value="large">대</option>' +
                                    '<option value="medium">중</option>' +
                                    '<option value="small">소</option>' +
                                '</select>' +
                            '</div>' +
                            '<div class="product-options">' +
                                '<label for="quantity-' + product._id + '">수량: </label>' +
                                '<input type="number" id="quantity-' + product._id + '" class="quantity-input" value="1" min="1" max="10">' +
                            '</div>' +              
                            '<button class="add-to-cart" data-pid="' + product._id + '">장바구니에 추가</button>' +
                            '</div>';
                        productGrid.appendChild(productCard);
                    });
                
                    // 장바구니 추가 버튼 이벤트 리스너
                    document.querySelectorAll('.add-to-cart').forEach(button => {
                        button.addEventListener('click', async function() {
                            const pid = this.dataset.pid;
                            console.log('Selected product ID:', pid); // 디버깅용
                            
                            const sizeElement = document.getElementById('size-' + pid);
                            const size = sizeElement ? sizeElement.value : undefined;
                            
                            const qtyElement = document.getElementById('quantity-' + pid);
                            const qty = qtyElement ? parseInt(qtyElement.value) : undefined;
                            
                            await addToCart(pid, size, qty);
                        });
                    });
                }
              
                // 장바구니에 상품 추가
                async function addToCart(pid, size, qty) {
                    console.log('Adding to cart:', { pid, size, qty }); // 디버깅용
                    try {
                        const response = await fetch('/cart/add', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                pid: pid.toString(), // ID를 문자열로 변환
                                size: size,
                                qty: qty
                            })
                        });
                
                        const data = await response.json();
                        
                        if (!response.ok) {
                            console.error('Server error:', data); // 디버깅용
                            throw new Error(data.message || '장바구니 추가 실패');
                        }
                
                        alert('상품이 장바구니에 추가되었습니다.');
                    } catch (error) {
                        console.error('Cart addition error:', error); // 디버깅용
                        alert('장바구니에 상품을 추가하는 데 실패했습니다: ' + error.message);
                    }
                }       
              
              
              // 페이지 로드 시 상품 데이터 가져오기
              fetchProducts();    
            </script>
          </body>
          </html>`;

        res.send(html);
    } catch (error) {
        console.error('Error in main page:', error);
        res.redirect('/auth/login');
    }
});

// 상품 목록 조회 API
app.get('/api/products', async (req, res) => {
    try {
        // MongoDB에서 모든 상품 정보 조회
        const products = await db.products.find().toArray();
        
        // MongoDB 문서를 클라이언트에 맞는 형식으로 변환
        const formattedProducts = products.map(product => ({
            ...product,
            _id: product._id.toString(),     // ObjectId를 문자열로 변환
            price: Number(product.price)      // 가격을 숫자형으로 확실하게 변환
        }));
        
        console.log('Formatted products:', formattedProducts);
        res.json(formattedProducts);        // JSON 형태로 응답
    } catch (err) {
        console.error('Error fetching products:', err);
        res.status(500).json({ error: err.message });
    }
});

// 장바구니 추가 API
app.post('/cart/add', async (req, res) => {
    try {
        // 요청 데이터 추출
        const { pid, size, qty } = req.body;
        console.log('장바구니 추가 요청:', { pid, size, qty });

        // 상품 ID 변환
        const productId = parseInt(pid);

        // 현재 로그인한 사용자 확인
        const statusUI = await authCheck.statusUI(req, res);
        const username = statusUI.split(' ')[0];
        
        // 사용자 정보 조회
        const user = await db.users.findOne({ username: username });
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // 상품 정보 조회
        const product = await db.products.findOne({ _id: productId });
        if (!product) {
            return res.status(404).json({ message: "Product not found" });
        }

        // 장바구니 아이템 생성
        const cartItem = {
            product_id: productId,
            product_name: product.pname,
            price: product.price,
            type: product.ptype,
            material: product.material,
            size: size,
            quantity: parseInt(qty)
        };
        
        // 사용자 문서의 cart 배열에 새 아이템 추가
        const result = await db.users.updateOne(
            { _id: user._id },                // 업데이트할 사용자 지정
            { $push: { cart: cartItem } }     // cart 배열에 새 아이템 추가
        );
        
        // 성공 응답
        res.json({ 
            message: 'Product added to cart',
            cartItemId: result.insertedId
        });
    } catch (error) {
        console.error('장바구니 추가 오류:', error);
        res.status(500).json({ error: error.message });
    }
});

// 서버 시작
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

// 앱 객체 외부 노출 (테스트 등에서 사용 가능)
module.exports = app;