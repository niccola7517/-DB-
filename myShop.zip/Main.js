const express = require('express')
const session = require('express-session')
const bodyParser = require('body-parser');
const FileStore = require('session-file-store')(session)
const cors = require('cors');
const path = require('path');

var authRouter = require('./auth');
var authCheck = require('./authCheck.js');
var template = require('./template.js');
var db = require('./db.js');
var cartRouter = require('./cartView.js');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: '~~~',	// 원하는 문자 입력
  resave: false,
  saveUninitialized: true,
  store:new FileStore(),
}));

// 장바구니 관련 라우트
app.use('/cart', cartRouter);

app.get('/', (req, res) => {
  if (!authCheck.isOwner(req, res)) {  // 로그인 안되어있으면 로그인 페이지로 이동시킴
    res.redirect('/auth/login');
    return false;
  } else {                             // 로그인 되어있으면 메인 페이지로 이동시킴
    res.redirect('/main');
    return false;
  }
})

// 인증 라우터
app.use('/auth', authRouter);

// 메인 페이지
app.get('/main', (req, res) => {
  if (!authCheck.isOwner(req, res)) {  // 로그인 안되어있으면 로그인 페이지로 이동시킴
    res.redirect('/auth/login');
    return false;
  }
  /*var html = template.HTML('Welcome',
    `<hr>
        <h2>메인 페이지에 오신 것을 환영합니다</h2>
        <p>로그인에 성공하셨습니다.</p>`,
    authCheck.statusUI(req, res)
  );*/
  var usermenu = authCheck.statusUI(req, res)
  var username = usermenu.split(' ')[0];
  
  var html = `
  <html lang="ko">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>의류 쇼핑몰</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .product-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
        }
        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .product-info {
            padding: 15px;
        }
        .product-name {
            font-size: 18px;
            font-weight: bold;
            margin: 0 0 10px 0;
        }
        .product-details {
            font-size: 14px;
            color: #666;
            margin: 5px 0;
        }
        .product-price {
            font-size: 16px;
            font-weight: bold;
            color: #e44d26;
            margin: 10px 0 0 0;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
  </head>
  <body>
    <h1>의류 쇼핑몰 상품 목록</h1>
    <h2>회원 ID : ${usermenu}</h2>
    <a href="/cart" id="cartLink">장바구니 보기</a>
    <div id="productGrid" class="product-grid">
        <!-- 상품 카드가 여기에 동적으로 추가됩니다 -->
    </div>
    <script>
      // 서버에서 상품 데이터 가져오기
      async function fetchProducts() {
          try {
              const response = await fetch('/api/products');
              if (!response.ok) {
                  throw new Error("HTTP error! status:" + response.status);
              }
              const products = await response.json();
              console.log(products)
              displayProducts(products);
          } catch (error) {
              console.error('상품을 가져오는 중 오류 발생:', error);
              document.getElementById('productGrid').innerHTML = '상품을 불러오는 중 오류가 발생했습니다.';
          }
      }
      
      // 상품 목록 표시
      function displayProducts(products) {
        const productGrid = document.getElementById('productGrid');
        console.log(productGrid);
        productGrid.innerHTML = ''; // 기존 내용 초기화
        products.forEach(product => {
          const productCard = document.createElement('div');
          productCard.className = 'product-card';
          productCard.innerHTML = 
            '<div class="product-info">' +
            '<h2 class="product-name">' + product.pname + '</h2>' +
            '<p class="product-details">종류: ' + product.ptype + '</p>' +
            '<p class="product-details">소재: ' + product.material + '</p>' +
            '<p class="product-price">' + product.price.toLocaleString() + '원</p>' +
            '<div class="product-options">' +
              '<label for="size-' + product.pid + '">사이즈: </label>' +
              '<select id="size-' + product.pid + '" class="size-select">' +
                '<option value="large">대</option>' +
                '<option value="medium">중</option>' +
                '<option value="small">소</option>' +
              '</select>' +
            '</div>' +
            '<div class="product-options">' +
              '<label for="quantity-' + product.pid + '">수량: </label>' +
              '<input type="number" id="quantity-' + product.pid + '" class="quantity-input" value="1" min="1" max="10">' +
            '</div>' +              
            '<button class="add-to-cart" data-pid="' + product.pid + '">장바구니에 추가</button>' +
            '</div>';
          console.log(productCard);  
          productGrid.appendChild(productCard);
        });
        
        // 모든 "장바구니에 추가" 버튼에 이벤트 리스너 추가
        document.querySelectorAll('.add-to-cart').forEach(button => {
          button.addEventListener('click', async function() {
            const pid = this.dataset.pid;
            
            const sizeElement = document.getElementById('size-' + pid);
            console.log('Size Element:', sizeElement);
            const size = sizeElement ? sizeElement.value : undefined;
            console.log('Size:', size);
            
            const qtyElement = document.getElementById('quantity-' + pid);
            console.log('Quantity Element:', qtyElement);
            const qty = qtyElement ? qtyElement.value : undefined;
            console.log('Quantity:', qty);
            
            addToCart(pid, size, qty);
          });
        });
      }
      
      // 장바구니에 상품 추가
      async function addToCart(pid, size, qty) {
        console.log('addToCart 함수 호출됨:', { pid, size, qty }); // 디버깅용 로그
        try {
          const response = await fetch('/cart/add', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              pid: pid,
              size: size,
              qty: qty
            })
          });
      
          if (!response.ok) {
            throw new Error('HTTP error! status: ' + response.status);
          }
      
          const data = await response.json();
          console.log('서버 응답:', data);
          alert('상품이 장바구니에 추가되었습니다.');
          // 여기에 장바구니 UI를 업데이트하는 로직을 추가할 수 있습니다
        } catch (error) {
          console.error('장바구니 추가 오류:', error);
          alert('장바구니에 상품을 추가하는 데 실패했습니다: ' + error.message);
        }
      }        
      
      
      // 페이지 로드 시 상품 데이터 가져오기
      fetchProducts();    
    </script>
  </body>
  </html>`;
  
  res.send(html);
})

// 서버 시작
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

// 상품 목록 조회 API
app.get('/api/products', async (req, res) => {
  try {
    // 데이터베이스에서 모든 상품 정보를 조회합니다.
    const [results] = await db.query('SELECT * FROM product');
    res.json(results);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: err.message });
  }
});

// 장바구니에 상품 추가 API
app.post('/cart/add', async (req, res) => {
  console.log('POST /cart/add 요청 받음');
  const { pid, size, qty } = req.body;
  
  console.log('요청 바디:', { pid, size, qty });
  
  try {
    console.log('authCheck.statusUI 호출 전');
    const username = authCheck.statusUI(req, res).split(' ')[0];
    console.log('authCheck.statusUI 결과:', username);
    
    if (!username) {
      console.log('사용자를 찾을 수 없음');
      return res.status(404).json({ message: "User not found" });
    }
    
    // 장바구니에 상품 추가 쿼리
    const query = 'INSERT INTO cart(mid, pid, size, qty) \
                   SELECT id, ?, ?, ? \
                   FROM userTable \
                   WHERE username = ?';
    console.log('실행할 쿼리:', query);
    console.log('쿼리 파라미터:', [pid, size, qty, username]);
    
    const [results] = await db.query(query, [pid, size, qty, username]);
    console.log('쿼리 실행 결과:', results);
    
    res.json({ message: 'Product added to cart' });
  } catch (error) {
    console.error('Error in /cart/add:', error);
    res.status(500).json({ error: error.message });
  }
});