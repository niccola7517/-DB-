const express = require('express');
const router = express.Router();
const db = require('./db'); // 데이터베이스 연결 모듈
const cors = require('cors');
var authCheck = require('./authCheck.js');

const app = express();

app.use(cors());

router.get('/', async (req, res) => {
 
  const username = authCheck.statusUI(req, res).split(' ')[0];
  
  // 데이터베이스에서 현재 사용자의 장바구니 아이템 조회
  const [cartItems] = await db.query('SELECT c.cid, p.pname, p.price, c.size, c.qty FROM cart c, product p, userTable u WHERE c.pid = p.pid and c.mid = u.id and u.username = ?', [username]);
  
  // 장바구니 HTML 생성
  var html = `
  <html lang="ko">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>장바구니</title>
      <style>
          body { font-family: Arial, sans-serif; }
          .cart-item { border: 1px solid #ddd; margin: 10px; padding: 10px; }
          #cartTotal { font-weight: bold; margin-top: 20px; }
      </style>
  </head>
  <body>
      <h1>장바구니</h1>
      <h2>회원 ID : ${username}</h2>
      <div id="cartItems">
          ${cartItems.map(item => `
              <div class="cart-item">
                  <h3>${item.pname}</h3>
                  <p>가격: ${item.price}원</p>
                  <p>사이즈: 
                      <select class="size-select" data-id="${item.cid}">
                          <option value="small" ${item.size === 'small' ? 'selected' : ''}>소</option>
                          <option value="medium" ${item.size === 'medium' ? 'selected' : ''}>중</option>
                          <option value="large" ${item.size === 'large' ? 'selected' : ''}>대</option>
                      </select>
                  </p>
                  <p>수량: 
                      <input type="number" class="quantity-input" data-id="${item.cid}" value="${item.qty}" min="1" max="10">
                  </p>
                  <button class="remove-item" data-id="${item.cid}">삭제</button>
              </div>
          `).join('')}
      </div>
      <div id="cartTotal">총 금액: <span id="totalAmount">0</span>원</div>
      <button id="paymentButton">결제하기</button>

      <script>
         // 장바구니 아이템 가져오기
        async function fetchCartItems() {
            try {
                const response = await fetch('/cart/cart_view');
                if (!response.ok) {
                    throw new Error("HTTP error! status:" + response.status);
                }
                const cartItems = await response.json();
                displayCartItems(cartItems);
                console.error('장바구니 아이템을 가져옴');
            } catch (error) {
                console.error('장바구니 아이템을 가져오는 중 오류 발생:', error);
                document.getElementById('cartItems').innerHTML = '장바구니를 불러오는 중 오류가 발생했습니다.';
            }
        }        

      // 장바구니 아이템 표시
      function displayCartItems(items) {
          const cartItemsContainer = document.getElementById('cartItems');
          cartItemsContainer.innerHTML = '';
          let total = 0;

          items.forEach(item => {
              const itemElement = document.createElement('div');
              itemElement.className = 'cart-item';
              itemElement.innerHTML = '<h3>' + item.pname + '</h3>' +
                  '<p> 장바구니번호: ' + item.cid + '</p>' +
                  '<p>가격: ' + item.price + '원</p>' +
                  '<p>사이즈: ' +
                      '<select class="size-select" data-id="' + item.cid + '">' +
                          '<option value="small"' + (item.size === 'small' ? ' selected' : '') + '>소</option>' +
                          '<option value="medium"' + (item.size === 'medium' ? ' selected' : '') + '>중</option>' +
                          '<option value="large"' + (item.size === 'large' ? ' selected' : '') + '>대</option>' +
                      '</select>' +
                  '</p>' +
                  '<p>수량: ' +
                      '<input type="number" class="quantity-input" data-id="' + item.cid + '" value="' + item.qty + '" min="1" max="10">' +
                  '</p>' +
                  '<button class="remove-item" data-id="' + item.cid + '">삭제</button>';
              cartItemsContainer.appendChild(itemElement);
              total += item.price * item.qty;
          });

          document.getElementById('totalAmount').textContent = total.toLocaleString();

          // 이벤트 리스너 추가
          addEventListeners();
      }

      function addEventListeners() {
          // 수량 변경 이벤트
          document.querySelectorAll('.quantity-input').forEach(input => {
              input.addEventListener('change', handleQuantityChange);
          });
      
          // 사이즈 변경 이벤트
          document.querySelectorAll('.size-select').forEach(select => {
              select.addEventListener('change', handleSizeChange);
          });
      
          // 삭제 버튼 이벤트
          document.querySelectorAll('.remove-item').forEach(button => {
              button.addEventListener('click', handleRemoveItem);
          });
      
          // 결제 버튼 이벤트
          const paymentButton = document.getElementById('paymentButton');
          paymentButton.removeEventListener('click', handlePayment);
          paymentButton.addEventListener('click', handlePayment);
      }
      
      async function handleQuantityChange() {
          const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
          const newQuantity = this.value;
          await updateCartItem(id, { quantity: newQuantity });
      }
      
      async function handleSizeChange() {
          const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
          const newSize = this.value;
          await updateCartItem(id, { size: newSize });
      }
      
      async function handleRemoveItem() {
          const id = this.dataset.id; // 현재 html 요소의 data-id 속성의 값을 가져옴
          await removeCartItem(id);
      }
      
      async function handlePayment() {
          await processPayment();
      }
    
      async function updateCartItem(id, updates) {
          try {
              const response = await fetch('/cart/' + id, {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(updates)
              });
              if (!response.ok) throw new Error('Failed to update cart item');
              console.log('장바구니가 업데이트되었습니다. id : ', id);
              await fetchCartItems(); // 장바구니 새로고침
          } catch (error) {
              console.error('Cart update error:', error);
              alert('장바구니 업데이트에 실패했습니다.');
          }
      }
    
      async function removeCartItem(id) {
          try {
              const response = await fetch('/cart/' + id, { method: 'DELETE' });
              if (!response.ok) throw new Error('Failed to remove cart item');
              console.log('장바구니가 품목이 삭제되었습니다. id : ', id);
              await fetchCartItems(); // 장바구니 새로고침
          } catch (error) {
              console.error('Cart removal error:', error);
              alert('상품 삭제에 실패했습니다.');
          }
      }
      
      async function processPayment() {
          try {
            const response = await fetch('/cart/pay', { 
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              }
            });
            if (!response.ok) throw new Error('Failed to process payment');
            const result = await response.json();
            alert(result.message);
            await fetchCartItems(); // 장바구니 새로고침
          } catch (error) {
            console.error('Payment error:', error);
            alert('결제 처리에 실패했습니다.');
          }
      }   
    
      // 페이지 로드 시 장바구니 아이템 가져오기
      fetchCartItems();
    </script>
  </body>
  </html>
`;
  
res.send(html);
})

// 장바구니 조회
router.get('/cart_view', async (req, res) => {
  try {
    
    const username = authCheck.statusUI(req, res).split(' ')[0];
 
    // 데이터베이스에서 사용자의 장바구니 아이템 조회
    const [cartItems] = await db.query('SELECT c.cid, p.pname, p.price, c.size, c.qty FROM cart c, product p, userTable u WHERE c.pid = p.pid and c.mid = u.id and u.username = ?', [username]);
    
    // HTML 생성 및 응답
    // const html = generateCartHTML(cartItems);
    // res.send(html);
    
    // JSON 데이터로 응답
    res.json(cartItems);    
  } catch (error) {
    console.error('장바구니 조회 오류:', error);
    res.status(500).send('서버 오류가 발생했습니다.');
  }
});

// 장바구니 아이템 업데이트
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { size, quantity } = req.body;
    if (size) {
        await db.query('UPDATE cart SET size = ? WHERE cid = ?', [size, id]);
    }
    if (quantity) {
        await db.query('UPDATE cart SET qty = ? WHERE cid = ?', [quantity, id]);
    }
    res.json({ message: '장바구니가 업데이트되었습니다.' });
  } catch (error) {
    console.error('장바구니 업데이트 오류:', error);
    res.status(500).json({ error: '서버 오류가 발생했습니다.' });
  }
});

// 장바구니 아이템 삭제
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM cart WHERE cid = ?', [id]);
    res.json({ message: '상품이 장바구니에서 삭제되었습니다.' });
  } catch (error) {
    console.error('장바구니 삭제 오류:', error);
    res.status(500).json({ error: '서버 오류가 발생했습니다.' });
  }
});

// 결제 처리
router.post('/pay', async (req, res) => {
  const username = authCheck.statusUI(req, res).split(' ')[0];
  try {
    const query_1 = 'INSERT INTO orders (mid, orderdate) \
                     SELECT id, date(now()) FROM userTable WHERE username = ?';
    await db.query(query_1, [username]);
    console.log('orders inserted');
    
    const query_2 = 'INSERT INTO order_items (oid, pid, size, qty) \
                     SELECT a.oid, b.pid, b.size, b.qty \
                     FROM (SELECT max(o.oid) oid, mid FROM userTable u, orders o WHERE u.username = ? and u.id = o.mid group by o.mid) a, \
                          cart b \
                     WHERE a.mid = b.mid';
    await db.query(query_2, [username]);
    console.log('order_items inserted');

    const query_3 = 'DELETE FROM cart WHERE mid = (SELECT id FROM userTable WHERE username = ?)';
    await db.query(query_3, [username]);

    res.json({ message: username + ' paid successfully!' });
  } catch (error) {
    console.error('결제 처리 오류:', error);
    res.status(500).json({ error: '서버 오류가 발생했습니다.' });
  }
});

module.exports = router;