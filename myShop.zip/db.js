var mysql = require('mysql2/promise');

var db = mysql.createPool({
    host: 'mysql-db.cdsomq8mgfd0.ap-south-1.rds.amazonaws.com',
    user: 'admin',
    password: 'mysql1234',
    database: 'member_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0    
});

// 연결 테스트
db.getConnection()
    .then(connection => {
        console.log('데이터베이스에 성공적으로 연결되었습니다.');
        connection.release();
    })
    .catch(err => {
        console.error('데이터베이스 연결 오류:', err);
    });

module.exports = db;